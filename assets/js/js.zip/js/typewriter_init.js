const instance = new Typewriter('#js-typewriter', {
	strings: ['UI/UX Designer', 'Art Director', 'Web Developer'],
	autoStart: true,
	loop: true,
});